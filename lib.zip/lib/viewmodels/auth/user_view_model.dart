// 📁 lib/viewmodels/auth/user_view_model.dart

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:kakao_flutter_sdk_user/kakao_flutter_sdk_user.dart';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:flutter_application_onjungapp/utils/shared_preferences.dart'; // ✅ 추가

class UserViewModel extends ChangeNotifier {
  String? uid;
  String? nickname;
  String? loginMethod;

  bool get isLoggedIn => uid != null;

  /// 🔹 카카오 로그인
  Future<void> signInWithKakao() async {
    try {
      final isInstalled = await isKakaoTalkInstalled();
      OAuthToken token = isInstalled
          ? await UserApi.instance.loginWithKakaoTalk()
          : await UserApi.instance.loginWithKakaoAccount();

      final user = await UserApi.instance.me();
      uid = 'kakao_${user.id}';
      nickname = user.kakaoAccount?.profile?.nickname ?? '카카오 사용자';
      loginMethod = 'kakao';

      await _saveUserToFirestore();
      await PrefsHelper.saveLoginInfo(
        uid: uid!,
        nickname: nickname,
        loginMethod: loginMethod,
      );

      debugPrint('✅ 카카오 로그인 성공: $uid / $nickname');
      notifyListeners();
    } catch (e) {
      debugPrint('❌ 카카오 로그인 실패: $e');
      rethrow;
    }
  }

  /// 🔹 애플 로그인
  Future<void> signInWithApple() async {
    try {
      final credential = await SignInWithApple.getAppleIDCredential(
        scopes: [
          AppleIDAuthorizationScopes.email,
          AppleIDAuthorizationScopes.fullName
        ],
      );

      uid = 'apple_${credential.userIdentifier}';
      nickname = credential.givenName ?? 'Apple 사용자';
      loginMethod = 'apple';

      await _saveUserToFirestore();
      await PrefsHelper.saveLoginInfo(
        uid: uid!,
        nickname: nickname,
        loginMethod: loginMethod,
      );

      debugPrint('✅ 애플 로그인 성공: $uid / $nickname');
      notifyListeners();
    } catch (e) {
      debugPrint('❌ 애플 로그인 실패: $e');
      rethrow;
    }
  }

  /// 🔸 로그인 정보 복원 (SplashPage에서 사용)
  Future<void> restoreUserFromPrefs() async {
    final data = await PrefsHelper.loadLoginInfo();
    uid = data['uid'];
    nickname = data['nickname'];
    loginMethod = data['loginMethod'];

    if (uid != null) {
      debugPrint('🔄 로그인 복원됨: $uid / $nickname');
      notifyListeners();
    }
  }

  /// 🔸 Firestore에 사용자 정보 저장
  Future<void> _saveUserToFirestore() async {
    final docRef = FirebaseFirestore.instance.collection('users').doc(uid);
    await docRef.set({
      'nickname': nickname,
      'loginMethod': loginMethod,
      'signedInAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  /// 🔸 로그아웃
  Future<void> signOut() async {
    if (loginMethod == 'kakao') {
      try {
        await UserApi.instance.logout();
        print('카카오 로그아웃 완료');
      } catch (e) {
        print('카카오 로그아웃 실패: $e');
      }
    }

    // 로컬 데이터 제거
    await PrefsHelper.clearLoginInfo();

    // 상태 초기화
    uid = null;
    nickname = null;
    loginMethod = null;
    notifyListeners();
  }

  /// 🔸 회원탈퇴
  Future<void> deleteAccount() async {
    if (uid == null) return;
    final firestore = FirebaseFirestore.instance;

    try {
      final myEvents = await firestore
          .collection('myEvents')
          .where('userId', isEqualTo: uid)
          .get();
      for (final doc in myEvents.docs) {
        await firestore.collection('myEvents').doc(doc.id).delete();
      }

      final eventRecords = await firestore
          .collection('eventRecords')
          .where('userId', isEqualTo: uid)
          .get();
      for (final doc in eventRecords.docs) {
        await firestore.collection('eventRecords').doc(doc.id).delete();
      }

      await firestore.collection('users').doc(uid).delete();

      print('✅ 탈퇴: 유저 및 연관 데이터 모두 삭제 완료');
    } catch (e) {
      print('❌ 탈퇴 중 오류 발생: $e');
    }

    await signOut();
  }
}
