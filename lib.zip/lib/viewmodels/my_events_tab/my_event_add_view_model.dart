// 📁 lib/viewmodels/my_events_tab/my_event_add_view_model.dart

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_application_onjungapp/models/enums/event_type.dart';
import 'package:flutter_application_onjungapp/models/my_event_model.dart';
import 'package:flutter_application_onjungapp/models/friend_model.dart';
import 'package:flutter_application_onjungapp/repositories/friend_repository.dart';
import 'package:flutter_application_onjungapp/repositories/my_event_repository.dart';
import 'package:flutter_application_onjungapp/repositories/event_record_repository.dart';

/// 🧠 경조사 추가 단계별 상태
class MyEventAddState {
  final EventType? selectedEventType;
  final DateTime? selectedDate;
  final List<Friend> friends;
  final Set<String> selectedFriendIds;
  final List<String> flowerFriendNames;
  final bool isFriendLoading;

  const MyEventAddState({
    this.selectedEventType,
    this.selectedDate,
    this.friends = const [],
    this.selectedFriendIds = const {},
    this.flowerFriendNames = const [],
    this.isFriendLoading = false,
  });

  MyEventAddState copyWith({
    EventType? selectedEventType,
    DateTime? selectedDate,
    List<Friend>? friends,
    Set<String>? selectedFriendIds,
    List<String>? flowerFriendNames,
    bool? isFriendLoading,
  }) {
    return MyEventAddState(
      selectedEventType: selectedEventType ?? this.selectedEventType,
      selectedDate: selectedDate ?? this.selectedDate,
      friends: friends ?? this.friends,
      selectedFriendIds: selectedFriendIds ?? this.selectedFriendIds,
      flowerFriendNames: flowerFriendNames ?? this.flowerFriendNames,
      isFriendLoading: isFriendLoading ?? this.isFriendLoading,
    );
  }
}

/// 🧠 경조사 추가 뷰모델
class MyEventAddViewModel extends Notifier<MyEventAddState> {
  final titleController = TextEditingController();
  final titleFocus = FocusNode();
  final _friendRepo = FriendRepository();
  final _eventRepo = MyEventRepository();
  final _recordRepo = EventRecordRepository();

  List<TextEditingController> flowerControllers = [];

  @override
  MyEventAddState build() => const MyEventAddState();

  /// ▶︎ Step1 완료 여부: 제목/종류/날짜 모두 선택되었는지
  bool get isStep1Complete =>
      titleController.text.trim().isNotEmpty &&
      state.selectedEventType != null &&
      state.selectedDate != null;

  /// ● 이벤트 종류 선택
  void setEventType(EventType? t) =>
      state = state.copyWith(selectedEventType: t);

  /// ● 날짜 선택
  void setDate(DateTime d) => state = state.copyWith(selectedDate: d);

  /// ● 친구 목록 로드 (Step2)
  Future<void> loadFriends(String userId) async {
    state = state.copyWith(isFriendLoading: true);
    try {
      final list = await _friendRepo.getFriendsByOwner(userId);
      state = state.copyWith(friends: list, isFriendLoading: false);
    } catch (_) {
      state = state.copyWith(isFriendLoading: false);
    }
  }

  /// ● 친구 선택/해제 토글
  void toggleFriend(String id) {
    final set = {...state.selectedFriendIds};
    set.contains(id) ? set.remove(id) : set.add(id);
    state = state.copyWith(selectedFriendIds: set);
  }

  /// ● 화환 컨트롤러 초기화 (Step3)
  void initFlowerControllers() {
    flowerControllers = state.flowerFriendNames
        .map((n) => TextEditingController(text: n))
        .toList();
    if (flowerControllers.isEmpty)
      flowerControllers.add(TextEditingController());
  }

  /// ● 화환 친구 추가/제거
  void addFlowerFriend() {
    flowerControllers.add(TextEditingController());
    state = state.copyWith(flowerFriendNames: [...state.flowerFriendNames, '']);
  }

  void removeFlowerFriend(int i) {
    flowerControllers[i].dispose();
    flowerControllers.removeAt(i);
    final names = [...state.flowerFriendNames]..removeAt(i);
    state = state.copyWith(flowerFriendNames: names);
  }

  void updateFlowerName(int i, String v) {
    final names = [...state.flowerFriendNames];
    names[i] = v;
    state = state.copyWith(flowerFriendNames: names);
  }

  /// ● 최종 이벤트 생성 & 저장
  Future<MyEvent?> submit(String userId) async {
    if (!isStep1Complete) return null;
    final now = DateTime.now();
    final id = const Uuid().v4();
    final event = MyEvent(
      id: id,
      title: titleController.text.trim(),
      eventType: state.selectedEventType!,
      date: state.selectedDate!,
      createdBy: userId,
      createdAt: now,
      updatedAt: now,
      recordIds: state.selectedFriendIds.toList(),
      flowerFriendNames: flowerControllers
          .map((c) => c.text.trim())
          .where((s) => s.isNotEmpty)
          .toList(),
    );
    try {
      await _eventRepo.addMyEvent(event);
      return event;
    } catch (_) {
      return null;
    }
  }

  /// ● 리소스 정리
  void disposeControllers() {
    titleController.dispose();
    titleFocus.dispose();
    for (final c in flowerControllers) c.dispose();
  }
}

/// 🔹 Provider 등록
final myEventAddViewModelProvider =
    NotifierProvider<MyEventAddViewModel, MyEventAddState>(
        MyEventAddViewModel.new);
