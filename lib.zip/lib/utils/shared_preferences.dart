import 'package:shared_preferences/shared_preferences.dart';

class PrefsHelper {
  static const String _uidKey = 'uid';
  static const String _nicknameKey = 'nickname';
  static const String _loginMethodKey = 'loginMethod';

  /// ✅ 로그인 정보 저장
  static Future<void> saveLoginInfo({
    required String uid,
    required String? nickname,
    required String? loginMethod,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_uidKey, uid);
    await prefs.setString(_nicknameKey, nickname ?? '');
    await prefs.setString(_loginMethodKey, loginMethod ?? '');
  }

  /// ✅ 로그인 정보 삭제
  static Future<void> clearLoginInfo() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_uidKey);
    await prefs.remove(_nicknameKey);
    await prefs.remove(_loginMethodKey);
  }

  /// ✅ 로그인 정보 복원
  static Future<Map<String, String?>> loadLoginInfo() async {
    final prefs = await SharedPreferences.getInstance();
    return {
      'uid': prefs.getString(_uidKey),
      'nickname': prefs.getString(_nicknameKey),
      'loginMethod': prefs.getString(_loginMethodKey),
    };
  }
}
