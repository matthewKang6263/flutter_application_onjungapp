// 📁 lib/pages/splash_page.dart

import 'package:flutter/material.dart';
import 'package:flutter_application_onjungapp/viewmodels/auth/user_view_model.dart';
import 'package:provider/provider.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    final userViewModel = context.read<UserViewModel>();

    // ✅ 로그인 정보 복원 시도
    await userViewModel.restoreUserFromPrefs();

    // ✅ 2초 대기 후 홈 또는 로그인 이동
    await Future.delayed(const Duration(seconds: 2));

    if (!mounted) return;

    final message = ModalRoute.of(context)?.settings.arguments as String?;

    Navigator.pushReplacementNamed(
      context,
      userViewModel.isLoggedIn ? '/home' : '/login',
      arguments: message, // snackBar 메시지가 있다면 그대로 전달
    );
  }

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      backgroundColor: Color(0xFFC9885C), // 피그마 배경색
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: Center(
                child: Text(
                  '온정',
                  style: TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Pretendard',
                    color: Colors.white,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
